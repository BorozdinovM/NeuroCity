﻿
var canvas = document.getElementById('c1');
var ctx = canvas.getContext('2d');
var i=0;
setTimeout("drawFrame()", 20);
function drawFrame()
{
	ctx.clearRect(0, 0, canvas.width, canvas.height)
	ctx.strokeRect(10+i, 10, 200, 100);
	ctx.strokeRect(690, 10+i, 100, 100);

	ctx.beginPath();
	ctx.moveTo(10, 590-i);
	ctx.lineTo(110, 590-i);
	ctx.lineTo(60, 490-i);
	ctx.lineTo(10, 590-i);
	ctx.stroke();

	ctx.beginPath();
	ctx.arc(700-i, 500, 80, 17*Math.PI/7, 13*Math.PI/2.9, false);
	ctx.stroke();
	
	i+=10;
	
	setTimeout("drawFrame()", 20);
}