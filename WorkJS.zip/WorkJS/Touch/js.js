﻿var slides = document.querySelectorAll('#slides .slide');
var currentSlide = 0;
slides[currentSlide].addEventListener('touchstart', nextSlide);

function nextSlide(){
    slides[currentSlide].className = 'slide';
    currentSlide = (currentSlide+1)%slides.length;
    slides[currentSlide].className = 'slide showing';
	slides[currentSlide].addEventListener('touchstart', nextSlide);
}
