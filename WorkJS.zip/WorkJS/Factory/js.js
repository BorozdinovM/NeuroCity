﻿class User {
    constructor(typeOfUser){
        this._canEditEverything = false;
        if (typeOfUser === "administrator") {
            this._canEditEverything = true;
        }
    }
    get canEditEverything() { return this._canEditEverything; }
	
	sayHi(){
		alert(this.canEditEverything);
	}
}

let u1 = new User("normalGuy");
let u2 = new User("administrator");
u1.sayHi();
u2.sayHi();